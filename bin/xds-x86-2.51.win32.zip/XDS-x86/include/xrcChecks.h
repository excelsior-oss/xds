/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcChecks_H_
#define xrcChecks_H_
#include "X2C.h"
#include "xmRTS.h"

extern unsigned short X2C_CHKINX_F(unsigned long, unsigned short);

extern unsigned long X2C_CHKINXL_F(unsigned long, unsigned long);

extern short X2C_CHKS_F(short);

extern long X2C_CHKSL_F(long);

extern short X2C_CHK_F(short, short, short);

extern long X2C_CHKL_F(long, long, long);

extern unsigned short X2C_CHKU_F(unsigned short, unsigned short,
                unsigned short);

extern unsigned long X2C_CHKUL_F(unsigned long, unsigned long,
                unsigned long);

extern X2C_pVOID X2C_CHKNIL_F(X2C_pVOID);

extern X2C_PROC X2C_CHKPROC_F(X2C_PROC);


#endif /* xrcChecks_H_ */

/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xosMem_H_
#define xosMem_H_
#include "X2C.h"

extern X2C_ADDRESS X2C_AllocMem(unsigned long);

extern void X2C_InitMem(void);

extern unsigned long X2C_GetAvailablePhysicalMemory(void);


#endif /* xosMem_H_ */

/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcIncDec_H_
#define xrcIncDec_H_
#include "X2C.h"

extern char X2C_INCC(char *, unsigned char, char, char);

extern signed char X2C_INCS(signed char *, signed char, signed char,
                signed char);

extern short X2C_INCI(short *, short, short, short);

extern long X2C_INC(long *, long, long, long);

extern unsigned char X2C_INCUS(unsigned char *, unsigned char, unsigned char,
                 unsigned char);

extern unsigned short X2C_INCUI(unsigned short *, unsigned short,
                unsigned short, unsigned short);

extern unsigned long X2C_INCU(unsigned long *, unsigned long, unsigned long,
                unsigned long);

extern char X2C_DECC(char *, unsigned char, char, char);

extern signed char X2C_DECS(signed char *, signed char, signed char,
                signed char);

extern short X2C_DECI(short *, short, short, short);

extern long X2C_DEC(long *, long, long, long);

extern unsigned char X2C_DECUS(unsigned char *, unsigned char, unsigned char,
                 unsigned char);

extern unsigned short X2C_DECUI(unsigned short *, unsigned short,
                unsigned short, unsigned short);

extern unsigned long X2C_DECU(unsigned long *, unsigned long, unsigned long,
                unsigned long);


#endif /* xrcIncDec_H_ */

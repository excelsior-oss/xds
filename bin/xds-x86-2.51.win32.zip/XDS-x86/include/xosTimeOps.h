/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xosTimeOps_H_
#define xosTimeOps_H_
#include "X2C.h"
#include "xlibOS.h"

extern long X2C_TimeCompare(struct X2C_TimeStruct, struct X2C_TimeStruct);

extern unsigned long X2C_TimeDayInt(struct X2C_TimeStruct,
                struct X2C_TimeStruct);

extern unsigned long X2C_TimeSecInt(struct X2C_TimeStruct,
                struct X2C_TimeStruct);

extern void X2C_TimeDayAdd(struct X2C_TimeStruct, unsigned long,
                struct X2C_TimeStruct *);

extern void X2C_TimeSecAdd(struct X2C_TimeStruct, unsigned long,
                struct X2C_TimeStruct *);

extern unsigned long X2C_TimeDayNum(unsigned long, unsigned long,
                unsigned long);


#endif /* xosTimeOps_H_ */

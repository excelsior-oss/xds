/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrSETs_H_
#define xrSETs_H_
#include "X2C.h"

extern long X2C_ASH(long, long);

extern unsigned long X2C_ROT(unsigned long, short, long);

extern unsigned long X2C_LSH(unsigned long, short, long);


#endif /* xrSETs_H_ */

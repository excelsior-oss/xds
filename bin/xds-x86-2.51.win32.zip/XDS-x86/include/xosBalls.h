/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xosBalls_H_
#define xosBalls_H_
#include "X2C.h"

extern X2C_ADDRESS X2C_initBalls(unsigned long, unsigned long);

extern X2C_ADDRESS X2C_allocBlock(X2C_ADDRESS);

extern void X2C_freeBlock(X2C_ADDRESS);

extern void X2C_freeAll(void);


#endif /* xosBalls_H_ */

/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrLSETs_H_
#define xrLSETs_H_
#include "X2C.h"
#include "xmRTS.h"

extern LSET X2C_ROTL(LSET, LSET, short, long);

extern LSET X2C_LSHL(LSET, LSET, short, long);

extern LSET X2C_INCL(LSET, unsigned long, unsigned short);

extern LSET X2C_EXCL(LSET, unsigned long, unsigned short);

extern char X2C_SET_EQU(LSET, LSET, unsigned short);

extern char X2C_SET_LEQ(LSET, LSET, unsigned short);

extern LSET X2C_LONGSET(LSET, unsigned long, unsigned long, unsigned short);

extern char X2C_INL(unsigned long, unsigned short, LSET);

extern LSET X2C_AND(LSET, LSET, LSET, unsigned short);

extern LSET X2C_OR(LSET, LSET, LSET, unsigned short);

extern LSET X2C_XOR(LSET, LSET, LSET, unsigned short);

extern LSET X2C_BIC(LSET, LSET, LSET, unsigned short);

extern LSET X2C_COMPLEMENT(LSET, LSET, unsigned short);


#endif /* xrLSETs_H_ */

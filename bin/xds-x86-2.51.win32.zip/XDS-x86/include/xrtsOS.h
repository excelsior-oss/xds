/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrtsOS_H_
#define xrtsOS_H_
#include "X2C.h"
#include "xmRTS.h"

typedef void *X2C_OSFILE;

#define X2C_beg 0

#define X2C_cur 1

#define X2C_end 2

extern int X2C_FileOpenRead(X2C_OSFILE *, char []);

extern int X2C_FileClose(X2C_OSFILE);

extern int X2C_FileSeek(X2C_OSFILE, X2C_WORD, int);

extern int X2C_FileOpenWrite(X2C_OSFILE *, char []);

extern int X2C_FileOpenRW(X2C_OSFILE *, char []);

extern int X2C_FileRead(X2C_OSFILE, X2C_ADDRESS, unsigned long *);

extern int X2C_FileWrite(X2C_OSFILE, X2C_ADDRESS, unsigned long *);

extern X2C_ADDRESS X2C_AllocMem(unsigned long);

extern void X2C_InitMem(void);

extern X2C_ADDRESS X2C_malloc(unsigned long);

extern void X2C_free(X2C_ADDRESS, unsigned long);

extern void X2C_InitHeap(unsigned long, char);

extern void X2C_ZEROMEM(X2C_ADDRESS, unsigned long);

extern void X2C_StdOut(char [], unsigned long);

extern void X2C_StdOutS(char [], unsigned long);

extern void X2C_StdOutD(unsigned long, unsigned long);

extern void X2C_StdOutH(unsigned long, unsigned long);

extern void X2C_StdOutN(void);

extern void X2C_StdOutFlush(void);

extern void X2C_DecToStr(char [], unsigned long *, unsigned long);

extern void X2C_HexToStr(char [], unsigned long *, unsigned long);

extern void X2C_EnableIpts(void);

extern void X2C_DisableIpts(void);

extern void X2C_SaveIptHandler(unsigned long);

extern void X2C_RestoreIptHandler(unsigned long);

extern char X2C_SetIptHandler(unsigned long);

extern void X2C_INT_HANDLER(unsigned long);

extern void X2C_iniexit(void);

extern void X2C_atexit(X2C_EXIT_PROC);

extern void X2C_doexit(long);

extern X2C_ADDRESS X2C_StackTop(void);


#endif /* xrtsOS_H_ */

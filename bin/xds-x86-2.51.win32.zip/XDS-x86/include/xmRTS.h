/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xmRTS_H_
#define xmRTS_H_
#include "X2C.h"
#include "xPOSIX.h"

#define X2C_MSG_LEN 1024

#define X2C_EXT 16

#define X2C_HIS_LEN 256

#define X2C_REGSIZE 64

typedef char * X2C_pCHAR;

typedef void * X2C_pVOID;

typedef unsigned long * LSET;

struct X2C_Profile_STR;

typedef struct X2C_Profile_STR * X2C_Profile;


struct X2C_Profile_STR {
   X2C_pCHAR name;
   long count;
   long time0;
   long total;
   X2C_Profile next;
   unsigned short tags;
};

struct X2C_his_rec;


struct X2C_his_rec {
   X2C_pCHAR fnm;
   short fln;
   unsigned short tags;
   X2C_Profile prf;
};

typedef struct X2C_his_rec X2C_HIS_BUFFER[256];

enum ProfilingModeType {PROF_MODE_NONE, PROF_MODE_MIN, PROF_MODE_STANDARD,
                PROF_MODE_FULL};


typedef unsigned char ProfilingModeSet;

struct X2C_Coroutine_STR;

typedef struct X2C_Coroutine_STR * X2C_Coroutine;

struct X2C_XHandler_STR;

typedef struct X2C_XHandler_STR * X2C_XHandler;

struct X2C_XSource_STR;

typedef struct X2C_XSource_STR * X2C_XSource;

typedef X2C_pCHAR * X2C_ppCHAR;

typedef X2C_pVOID * X2C_ppVOID;

typedef unsigned short * X2C_pCARD16;

typedef X2C_pCARD16 * X2C_ppCARD16;

struct X2C_TD_STR;

typedef struct X2C_TD_STR * X2C_TD;

struct X2C_MD_STR;

typedef struct X2C_MD_STR * X2C_MD;

struct X2C_LINK_STR;

typedef struct X2C_LINK_STR * X2C_LINK;


struct X2C_XSource_STR {
   unsigned long number;
   char message[1024];
};


struct X2C_Coroutine_STR {
   short prot;
   short int_no;
   X2C_ADDRESS stk_start;
   X2C_ADDRESS stk_end;
   X2C_Coroutine fwd;
   X2C_Coroutine bck;
   X2C_PROC proc;
   long magic;
   jmp_buf buf;
   X2C_XHandler handler;
   X2C_HIS_BUFFER his;
   short his_cnt;
   char his_msg[1024];
   unsigned long reg_dump[64];
   unsigned long reg_dsize;
};


struct X2C_XHandler_STR {
   short state;
   short history;
   X2C_XSource source;
   X2C_XHandler next;
   jmp_buf buf;
};


struct X2C_MD_STR {
   X2C_MD next;
   X2C_MD cnext;
   X2C_pCHAR name;
   X2C_ppVOID offs;
   X2C_PROC * cmds;
   X2C_ppCHAR cnms;
   X2C_TD types;
};


struct X2C_TD_STR {
   size_t size;
   X2C_pCHAR name;
   X2C_MD module;
   X2C_TD next;
   short methods;
   short level;
   X2C_TD base[16];
   X2C_PROC * proc;
   X2C_ppVOID offs;
   X2C_TD succ;
   X2C_LINK link;
   X2C_LINK tail;
   X2C_TD self;
   unsigned long res;
};


struct X2C_LINK_STR {
   union {
      X2C_TD td;
      X2C_LINK next;
      unsigned long dummy;
   } _;
   union {
      unsigned long size;
      unsigned long tags;
   } _0;
};

#define X2C_st_normal 0

#define X2C_st_exceptional 1

#define X2C_st_off 2

#define X2C_st_reraise 3

extern X2C_XSource X2C_rtsSource;

extern X2C_XSource X2C_assertSrc;

extern X2C_MD X2C_MODULES;

extern long X2C_hline;

extern char XDSLIB_INITIALIZATION_FAILED;

extern void X2C_SetCurrent(X2C_Coroutine);

extern X2C_Coroutine X2C_GetCurrent(void);

extern void X2C_ZEROMEM(X2C_ADDRESS, unsigned long);

extern char X2C_CAP(char);

extern int X2C_STRCMP_PROC(X2C_pVOID, size_t, X2C_pVOID, size_t);

extern long X2C_ASH(long, long);

extern unsigned long X2C_ROT(unsigned long, short, long);

extern LSET X2C_ROTL(LSET, LSET, short, long);

extern unsigned long X2C_LSH(unsigned long, short, long);

extern LSET X2C_LSHL(LSET, LSET, short, long);

extern LSET X2C_INCL(LSET, unsigned long, unsigned short);

extern LSET X2C_EXCL(LSET, unsigned long, unsigned short);

extern char X2C_SET_EQU(LSET, LSET, unsigned short);

extern char X2C_SET_LEQ(LSET, LSET, unsigned short);

extern LSET X2C_LONGSET(LSET, unsigned long, unsigned long, unsigned short);

extern LSET X2C_AND(LSET, LSET, LSET, unsigned short);

extern LSET X2C_OR(LSET, LSET, LSET, unsigned short);

extern LSET X2C_XOR(LSET, LSET, LSET, unsigned short);

extern LSET X2C_BIC(LSET, LSET, LSET, unsigned short);

extern LSET X2C_COMPLEMENT(LSET, LSET, unsigned short);

extern double X2C_EXPRI(double, long);

extern long X2C_ENTIER(double);

extern long X2C_TRUNCI(double, long, long);

extern unsigned long X2C_TRUNCC(double, unsigned long, unsigned long);

extern X2C_pVOID X2C_COPY(X2C_pVOID, size_t, X2C_pVOID, size_t);

extern size_t X2C_LENGTH(X2C_pVOID, size_t);

extern void X2C_XInitHandler(X2C_XHandler);

extern void X2C_XRETRY(void);

extern void X2C_XREMOVE(void);

extern void X2C_XOFF(void);

extern void X2C_XON(void);

extern void X2C_doRaise(X2C_XSource);

extern void X2C_init_exceptions(void);

extern void X2C_TRAP_FC(long, X2C_pCHAR, unsigned long);

extern void X2C_TRAP_F(long);

extern void X2C_ASSERT_F(unsigned long);

extern void X2C_ASSERT_FC(unsigned long, X2C_pCHAR, unsigned long);

extern void X2C_FINALEXE(X2C_PROC);

extern void X2C_FINALDLL(X2C_ADDRESS *, X2C_PROC);

extern void X2C_HALT(long);

extern void X2C_ABORT(void);

extern void X2C_EXIT(void);

extern void X2C_EXITDLL(X2C_ADDRESS *);

typedef void ( *X2C_EXIT_PROC)(void);

extern void X2C_atexit(X2C_EXIT_PROC);

extern void X2C_HIS_SAVE(short *);

extern void X2C_HIS_RESTORE(short);

extern void X2C_show_history(void);

extern void X2C_show_profile(void);

extern void X2C_ini_profiler(void);

extern void X2C_scanStackHistory(X2C_ADDRESS, X2C_ADDRESS, char);

extern void X2C_ini_termination(void);

extern short X2C_PROT(void);

extern void X2C_InitCoroutine(X2C_Coroutine, X2C_ADDRESS);

extern void X2C_RegisterCoroutine(X2C_Coroutine);

extern void X2C_UnregisterCoroutine(X2C_Coroutine);

extern void X2C_CopyJmpBuf(X2C_Coroutine);

extern void X2C_PROTECT(short *, short);

extern void X2C_TRANSFER(X2C_Coroutine *, X2C_Coroutine);

extern void X2C_IOTRANSFER(X2C_Coroutine *, X2C_Coroutine);

extern void X2C_NEWPROCESS(X2C_PROC, X2C_ADDRESS, unsigned long, short,
                X2C_Coroutine *);

extern void X2C_ini_coroutines(X2C_ADDRESS);

extern void X2C_reg_stackbotm(X2C_ADDRESS);

typedef size_t X2C_LENS_TYPE;

extern void X2C_ALLOCATE(X2C_ADDRESS *, size_t);

extern void X2C_DEALLOCATE(X2C_ADDRESS *);

extern void X2C_DYNALLOCATE(X2C_ADDRESS *, size_t, size_t [], size_t);

extern void X2C_DYNDEALLOCATE(X2C_ADDRESS *);

extern void X2C_DYNCALLOCATE(X2C_ADDRESS *, size_t, size_t [], size_t);

extern void X2C_DYNCDEALLOCATE(X2C_ADDRESS *);

extern void X2C_NEW(X2C_TD, X2C_ADDRESS *, size_t, char);

extern void X2C_NEW_OPEN(X2C_TD, X2C_ADDRESS *, size_t, size_t [], size_t,
                char);

extern void X2C_DISPOSE(X2C_ADDRESS *);

extern void X2C_COLLECT(void);

extern void X2C_PrepareToGC(void);

extern void X2C_FreeAfterGC(void);

typedef void ( *X2C_DPROC)(X2C_ADDRESS);

extern void X2C_DESTRUCTOR(X2C_ADDRESS, X2C_DPROC);

extern X2C_pVOID X2C_GUARDP_F(X2C_pVOID, X2C_TD);

extern X2C_TD X2C_GUARDV_F(X2C_TD, X2C_TD);

extern X2C_pVOID X2C_GUARDPE_F(X2C_pVOID, X2C_TD);

extern X2C_TD X2C_GUARDVE_F(X2C_TD, X2C_TD);

extern char X2C_GC_INIT(char, unsigned long, unsigned long);

extern void X2C_GC_INCREASE(char, unsigned long, unsigned long);

extern void X2C_EXIT_PROFILER(char);

extern void X2C_MODULE(X2C_MD);

extern unsigned long X2C_objects;

extern unsigned long X2C_busymem;

extern unsigned long X2C_busylheap;

extern unsigned long X2C_smallbusy;

extern unsigned long X2C_normalbusy;

extern unsigned long X2C_largebusy;

extern unsigned long X2C_usedmem;

extern unsigned long X2C_smallused;

extern unsigned long X2C_normalused;

extern unsigned long X2C_usedlheap;

extern unsigned long X2C_maxmem;

extern unsigned long X2C_threshold;

extern X2C_TD x2c_td_null;

extern X2C_TD x2c_td_ptr;

extern char X2C_fs_init;

extern unsigned long X2C_MaxGCTimePercent;

extern char X2C_GCThrashWarning;

extern void X2C_BEGIN(int *, X2C_ppCHAR, int, long, long);

extern void X2C_INIT_RTS(void);

extern unsigned short X2C_CHKINX_F(unsigned long, unsigned short);

extern unsigned long X2C_CHKINXL_F(unsigned long, unsigned long);

extern short X2C_CHKS_F(short);

extern long X2C_CHKSL_F(long);

extern short X2C_CHK_F(short, short, short);

extern long X2C_CHKL_F(long, long, long);

extern unsigned short X2C_CHKU_F(unsigned short, unsigned short,
                unsigned short);

extern unsigned long X2C_CHKUL_F(unsigned long, unsigned long,
                unsigned long);

extern X2C_pVOID X2C_CHKNIL_F(X2C_pVOID);

extern X2C_PROC X2C_CHKPROC_F(X2C_PROC);

extern long X2C_REM_F(long, long);

extern long X2C_QUO_F(long, long);

extern long X2C_MOD_F(long, long);

extern long X2C_DIV_F(long, long);

extern char X2C_IN(unsigned long, unsigned short, unsigned long);

extern unsigned long X2C_SET(unsigned long, unsigned long, unsigned short);

extern char X2C_INL(unsigned long, unsigned short, LSET);

extern int CPLX_CMP(X2C_COMPLEX, X2C_COMPLEX);

extern X2C_COMPLEX CPLX_ADD(X2C_COMPLEX, X2C_COMPLEX);

extern X2C_COMPLEX CPLX_SUB(X2C_COMPLEX, X2C_COMPLEX);

extern X2C_COMPLEX CPLX_MUL(X2C_COMPLEX, X2C_COMPLEX);

extern X2C_COMPLEX CPLX_DIV(X2C_COMPLEX, X2C_COMPLEX);

extern X2C_COMPLEX CPLX_NEG(X2C_COMPLEX);

extern int CPLX_LCMP(X2C_LONGCOMPLEX, X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_LADD(X2C_LONGCOMPLEX, X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_LSUB(X2C_LONGCOMPLEX, X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_LMUL(X2C_LONGCOMPLEX, X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_LDIV(X2C_LONGCOMPLEX, X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_LNEG(X2C_LONGCOMPLEX);

extern X2C_LONGCOMPLEX CPLX_L(X2C_COMPLEX);

extern X2C_COMPLEX X2C_EXPCI(X2C_COMPLEX, long);

extern X2C_LONGCOMPLEX X2C_EXPLI(X2C_LONGCOMPLEX, long);

extern X2C_COMPLEX X2C_EXPCR(X2C_COMPLEX, double);

extern X2C_LONGCOMPLEX X2C_EXPLR(X2C_LONGCOMPLEX, double);

extern char X2C_INCC(char *, unsigned char, char, char);

extern signed char X2C_INCS(signed char *, signed char, signed char,
                signed char);

extern short X2C_INCI(short *, short, short, short);

extern long X2C_INC(long *, long, long, long);

extern unsigned char X2C_INCUS(unsigned char *, unsigned char, unsigned char,
                 unsigned char);

extern unsigned short X2C_INCUI(unsigned short *, unsigned short,
                unsigned short, unsigned short);

extern unsigned long X2C_INCU(unsigned long *, unsigned long, unsigned long,
                unsigned long);

extern char X2C_DECC(char *, unsigned char, char, char);

extern signed char X2C_DECS(signed char *, signed char, signed char,
                signed char);

extern short X2C_DECI(short *, short, short, short);

extern long X2C_DEC(long *, long, long, long);

extern unsigned char X2C_DECUS(unsigned char *, unsigned char, unsigned char,
                 unsigned char);

extern unsigned short X2C_DECUI(unsigned short *, unsigned short,
                unsigned short, unsigned short);

extern unsigned long X2C_DECU(unsigned long *, unsigned long, unsigned long,
                unsigned long);

extern float X2C_VAL_REAL(double);

extern signed char X2C_ABS_INT8(signed char);

extern short X2C_ABS_INT16(short);

extern long X2C_ABS_INT32(long);

extern void X2C_PCOPY(X2C_pVOID *, size_t);

extern void X2C_PFREE(X2C_pVOID);

extern void X2C_Profiler(void);

extern void X2C_PROC_INP_F(char [], long);

extern void X2C_PROC_PRF_F(char [], long, struct X2C_Profile_STR *);

extern void X2C_PROC_OUT_F(void);

extern void X2C_Profiler_clock(void);

extern void X2C_FINALLY(X2C_PROC);


#endif /* xmRTS_H_ */

/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcAri64_H_
#define xrcAri64_H_
#include "X2C.h"

extern X2C_INT64 X2C_REM64_F(X2C_INT64, X2C_INT64);

extern X2C_INT64 X2C_QUO64_F(X2C_INT64, X2C_INT64);

extern X2C_INT64 X2C_MOD64_F(X2C_INT64, X2C_INT64);

extern X2C_INT64 X2C_DIV64_F(X2C_INT64, X2C_INT64);

extern X2C_INT64 X2C_ABS_INT64(X2C_INT64);


#endif /* xrcAri64_H_ */

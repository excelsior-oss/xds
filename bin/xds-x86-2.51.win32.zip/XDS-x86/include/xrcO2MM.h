/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcO2MM_H_
#define xrcO2MM_H_
#include "X2C.h"
#include "xmRTS.h"

extern X2C_pVOID X2C_GUARDP_F(X2C_pVOID, X2C_TD);

extern X2C_TD X2C_GUARDV_F(X2C_TD, X2C_TD);

extern X2C_pVOID X2C_GUARDPE_F(X2C_pVOID, X2C_TD);

extern X2C_TD X2C_GUARDVE_F(X2C_TD, X2C_TD);


#endif /* xrcO2MM_H_ */

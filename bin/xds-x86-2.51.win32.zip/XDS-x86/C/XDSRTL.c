/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)XDSRTL.c Jun  9 16:08:50 2019" */
#include "XDSRTL.h"
#define XDSRTL_C_
#include "xmRTS.h"


extern void XDSRTL_Init(PINT argc, PPCHAR argv, long gcauto,
                long gcthreshold, long heaplimit)
{
   X2C_BEGIN(argc, (X2C_ppCHAR)argv, gcauto, gcthreshold, heaplimit);
} /* end XDSRTL_Init() */


extern void XDSRTL_Exit(void)
{
   X2C_EXIT();
} /* end XDSRTL_Exit() */


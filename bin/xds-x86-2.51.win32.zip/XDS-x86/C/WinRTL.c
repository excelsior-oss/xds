/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)WinRTL.c Jun  9 16:08:50 2019" */
#include <WinRTL.h>
#define WinRTL_C_


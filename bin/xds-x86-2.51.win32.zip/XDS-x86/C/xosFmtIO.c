/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtIO.c Jun  9 16:08:50 2019" */
#include "xosFmtIO.h"
#define xosFmtIO_C_
#include "xrtsOS.h"

#define spaces "        "


static void outs(char s[], unsigned long len)
{
   if (len==0ul) return;
   X2C_StdOut(s, len);
} /* end outs() */


extern void X2C_StdOutS(char s[], unsigned long w)
{
   unsigned long l;
   l = 0ul;
   while (s[l]) ++l;
   outs(s, l);
   if (w>l) {
      while (w-l>8ul) {
         outs("        ", 8ul);
         l += 8ul;
      }
      if (w>l) outs("        ", w-l);
   }
} /* end X2C_StdOutS() */


extern void X2C_HexToStr(char s[], unsigned long * pos, unsigned long no)
{
   unsigned long i;
   unsigned long d;
   *pos += 8ul;
   for (i = 0ul; i<=7ul; i++) {
      d = no&15ul;
      no = no/16ul;
      --*pos;
      if (d>9ul) s[*pos] = (char)((65ul+d)-10ul);
      else s[*pos] = (char)(48ul+d);
   } /* end for */
} /* end X2C_HexToStr() */


extern void X2C_StdOutH(unsigned long no, unsigned long w)
{
   char buf[12];
   unsigned long pos;
   pos = 0ul;
   X2C_HexToStr(buf, &pos, no);
   if (w>8ul) {
      while (w>16ul) {
         outs("        ", 8ul);
         w -= 8ul;
      }
      if (w>8ul) outs("        ", w-8ul);
   }
   outs(buf, 8ul);
} /* end X2C_StdOutH() */


extern void X2C_DecToStr(char s[], unsigned long * pos, unsigned long no)
{
   unsigned long i;
   unsigned long l;
   i = 1000000000ul;
   l = 10ul;
   while (i>no) {
      i = i/10ul;
      --l;
   }
   if (l==0ul) l = 1ul;
   *pos += l;
   i = *pos;
   while (l>0ul) {
      --i;
      s[i] = (char)(48ul+no%10ul);
      no = no/10ul;
      --l;
   }
} /* end X2C_DecToStr() */


extern void X2C_StdOutD(unsigned long no, unsigned long w)
{
   char buf[12];
   unsigned long pos;
   pos = 0ul;
   X2C_DecToStr(buf, &pos, no);
   if (w>pos) {
      while (w-pos>8ul) {
         outs("        ", 8ul);
         w -= 8ul;
      }
      if (w>pos) outs("        ", w-pos);
   }
   outs(buf, pos);
} /* end X2C_StdOutD() */


/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrSETs.c Jun  9 16:08:50 2019" */
#include "xrSETs.h"
#define xrSETs_C_


extern long X2C_ASH(long a, long b)
{
   return (b >= 0) ? (a << b) : (a >> (-b));
   return 0l;
} /* end X2C_ASH() */


extern unsigned long X2C_ROT(unsigned long a, short length, long n)
{
   unsigned long m;
   m = 0ul;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0l) {
      n=n % length;
      return ((a << n) | (a >> (length - n))) & m;
   }
   else {
      n= -n % length;
      return ((a >> n) | (a << (length - n))) & m;
   }
   return 0ul;
} /* end X2C_ROT() */


extern unsigned long X2C_LSH(unsigned long a, short length, long n)
{
   unsigned long m;
   m = 0ul;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0l) {
      if (n>=(long)length) return 0ul;
      return (a << n) & m;
   }
   else {
      if (n<=(long) -length) return 0ul;
      return (a >> -n) & m;
   }
   return 0ul;
} /* end X2C_LSH() */


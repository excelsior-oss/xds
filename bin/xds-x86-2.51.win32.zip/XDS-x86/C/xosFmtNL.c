/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtNL.c Jun  9 16:08:50 2019" */
#include "xosFmtNL.h"
#define xosFmtNL_C_
#include "xPOSIX.h"


extern void X2C_StdOutN(void)
{
   printf("\n");
} /* end X2C_StdOutN() */


/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrStrCmp.c Jun  9 16:08:50 2019" */
#include "xrStrCmp.h"
#define xrStrCmp_C_
#include "xmRTS.h"


extern int X2C_STRCMP_PROC(X2C_pVOID x, size_t alen, X2C_pVOID y,
                size_t blen)
{
   X2C_pCHAR b;
   X2C_pCHAR a;
   size_t m;
   size_t i;
   a = (X2C_pCHAR)x;
   b = (X2C_pCHAR)y;
   m = alen;
   if (m>blen) m = blen;
   i = 0u;
   while ((i<m && *a) && *a==*b) {
      a = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)a+(long)1ul);
      b = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)b+(long)1ul);
      ++i;
   }
   if (i>=m) {
      if (i<alen && *a==0) alen = i;
      if (i<blen && *b==0) blen = i;
      if (alen<blen) return -1;
      if (alen>blen) return 1;
      return 0;
   }
   if ((unsigned char)(*a)<(unsigned char)(*b)) return -1;
   if ((unsigned char)(*a)>(unsigned char)(*b)) return 1;
   return 0;
} /* end X2C_STRCMP_PROC() */


/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcAri64.c Jun  9 16:08:50 2019" */
#include "xrcAri64.h"
#define xrcAri64_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern X2C_INT64 X2C_REM64_F(X2C_INT64 a, X2C_INT64 b)
{
   if (b==0l) X2C_TRAP(6l);
   if (a>=0l) {
      if (b>0l) return (a%b);
      else return (a%(-b));
   }
   else if (b>0l) return (-((-a)%b));
   else return (-(-a)%(-b));
   return 0l;
} /* end X2C_REM64_F() */


extern X2C_INT64 X2C_QUO64_F(X2C_INT64 a, X2C_INT64 b)
{
   if (b==0l) X2C_TRAP(6l);
   if (a>=0l) {
      if (b>0l) return (a/b);
      else return (-(a/(-b)));
   }
   else if (b>0l) return (-((-a)/b));
   else return ((-a)/(-b));
   return 0l;
} /* end X2C_QUO64_F() */


extern X2C_INT64 X2C_MOD64_F(X2C_INT64 a, X2C_INT64 b)
{
   X2C_INT64 c;
   if (b<=0l) X2C_TRAP(6l);
   c = (a % b);
   if (a<0l && c<0l) c += b;
   return c;
} /* end X2C_MOD64_F() */


extern X2C_INT64 X2C_DIV64_F(X2C_INT64 a, X2C_INT64 b)
{
   X2C_INT64 c;
   if (b<=0l) X2C_TRAP(6l);
   c = (a/b);
   if (a<0l && c*b>a) --c;
   return c;
} /* end X2C_DIV64_F() */


extern X2C_INT64 X2C_ABS_INT64(X2C_INT64 x)
{
   if (x>=0l) return x;
   if (x==-0x08000000000000000l) X2C_TRAP(1l);
   return -x;
} /* end X2C_ABS_INT64() */


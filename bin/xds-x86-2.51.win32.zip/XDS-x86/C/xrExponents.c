/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrExponents.c Jun  9 16:08:50 2019" */
#include "xrExponents.h"
#define xrExponents_C_
#include "xmRTS.h"
#include "xPOSIX.h"


static double c_abs(double re, double im)
{
   return sqrt(re*re+im*im);
} /* end c_abs() */


static double c_arg(double re, double im)
{
   if (re==0.0 && im==0.0) return 0.0;
   return atan2(im, re);
} /* end c_arg() */


extern double X2C_EXPRI(double base, long ex)
{
   double res;
   if (ex<0l || ex>8l) return pow(base, (double)ex);
   res = 1.0;
   while (ex>0l) {
      res = res*base;
      --ex;
   }
   return res;
} /* end X2C_EXPRI() */

static X2C_COMPLEX _cnst = {1.0,0.0};

extern X2C_COMPLEX X2C_EXPCI(X2C_COMPLEX base, long ex)
{
   X2C_COMPLEX res;
   if (ex<0l || ex>8l) return X2C_EXPCR(base, (double)ex);
   res = _cnst;
   while (ex>0l) {
      res = CPLX_MUL(res, base);
      --ex;
   }
   return res;
} /* end X2C_EXPCI() */

static X2C_LONGCOMPLEX _cnst1 = {1.0,0.0};

extern X2C_LONGCOMPLEX X2C_EXPLI(X2C_LONGCOMPLEX base, long ex)
{
   X2C_LONGCOMPLEX res;
   if (ex<0l || ex>8l) return X2C_EXPLR(base, (double)ex);
   res = _cnst1;
   while (ex>0l) {
      res = CPLX_LMUL(res, base);
      --ex;
   }
   return res;
} /* end X2C_EXPLI() */

static X2C_COMPLEX _cnst0 = {0.0,0.0};

extern X2C_COMPLEX X2C_EXPCR(X2C_COMPLEX base, double ex)
{
   float x;
   double y;
   X2C_COMPLEX tmp;
   if ((base.re==0.0f && base.im==0.0f) && ex>0.0) return _cnst0;
   x = (float)pow(c_abs((double)base.re, (double)base.im), ex);
   y = ex*c_arg((double)base.re, (double)base.im);
   return (tmp.re = x*(float)cos(y),tmp.im = x*(float)sin(y),tmp);
} /* end X2C_EXPCR() */

static X2C_LONGCOMPLEX _cnst2 = {0.0,0.0};

extern X2C_LONGCOMPLEX X2C_EXPLR(X2C_LONGCOMPLEX base, double ex)
{
   double y;
   double x;
   X2C_LONGCOMPLEX tmp;
   if ((base.re==0.0 && base.im==0.0) && ex>0.0) return _cnst2;
   x = pow(c_abs(base.re, base.im), ex);
   y = ex*c_arg(base.re, base.im);
   return (tmp.re = x*cos(y),tmp.im = x*sin(y),tmp);
} /* end X2C_EXPLR() */

